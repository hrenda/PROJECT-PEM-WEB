<?php
require 'koneksi.php';
session_start();
if (!isset($_SESSION['user_username'])) {
    header('Location: login.php');
    exit;
}
$username = $_SESSION['user_username'];
$sql = "SELECT b.*, l.nama_layanan, l.harga FROM booking b LEFT JOIN layanan l ON b.layanan_id=l.id WHERE b.nama='$username' ORDER BY b.id DESC";
$booking = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Riwayat Booking - Barbers</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Riwayat Booking Saya</h2>
        <a href="index.php" class="btn btn-secondary mb-3">&larr; Kembali ke Beranda</a>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Layanan</th>
                    <th>Komentar</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Status</th>
                    <th>Catatan Admin</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; while($row = mysqli_fetch_assoc($booking)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['nama_layanan']) ?> <br><small>Rp <?= number_format($row['harga'],0,',','.') ?></small></td>
                    <td><?= htmlspecialchars($row['komentar']) ?></td>
                    <td><?= htmlspecialchars($row['tanggal']) ?></td>
                    <td><?= htmlspecialchars($row['jam']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= htmlspecialchars($row['catatan_admin']) ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html> 