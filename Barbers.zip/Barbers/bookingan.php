<?php
require 'koneksi.php';
session_start();
if (!isset($_SESSION['admin_username'])) {
    header('Location: login.php');
    exit;
}
// Update status/catatan
if (isset($_POST['update_status'])) {
    $id = (int)$_POST['id'];
    $status = $_POST['status'];
    $catatan = mysqli_real_escape_string($conn, $_POST['catatan_admin']);
    mysqli_query($conn, "UPDATE booking SET status='$status', catatan_admin='$catatan' WHERE id=$id");
}
// Hapus booking
if (isset($_POST['hapus_booking'])) {
    $id = (int)$_POST['id'];
    mysqli_query($conn, "DELETE FROM booking WHERE id=$id");
}
// Ambil data booking join layanan
$sql = "SELECT b.*, l.nama_layanan, l.harga FROM booking b LEFT JOIN layanan l ON b.layanan_id=l.id ORDER BY b.id DESC";
$booking = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bookingan - Barbers</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Daftar Bookingan</h2>
        <a href="index.php" class="btn btn-secondary mb-3">&larr; Kembali ke Beranda</a>
        <table class="table table-bordered table-striped">
            <thead class="thead-dark">
                <tr>
                    <th>No</th>
                    <th>Nama</th>
                    <th>Email</th>
                    <th>Telepon</th>
                    <th>Layanan</th>
                    <th>Komentar</th>
                    <th>Tanggal</th>
                    <th>Jam</th>
                    <th>Status</th>
                    <th>Catatan Admin</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $no=1; while($row = mysqli_fetch_assoc($booking)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td><?= htmlspecialchars($row['nama']) ?></td>
                    <td><?= htmlspecialchars($row['email']) ?></td>
                    <td><?= htmlspecialchars($row['telepon']) ?></td>
                    <td><?= htmlspecialchars($row['nama_layanan']) ?> <br><small>Rp <?= number_format($row['harga'],0,',','.') ?></small></td>
                    <td><?= htmlspecialchars($row['komentar']) ?></td>
                    <td><?= htmlspecialchars($row['tanggal']) ?></td>
                    <td><?= htmlspecialchars($row['jam']) ?></td>
                    <td><?= htmlspecialchars($row['status']) ?></td>
                    <td><?= htmlspecialchars($row['catatan_admin']) ?></td>
                    <td>
                        <form method="POST" style="min-width:160px; display:flex; flex-direction:row; align-items:center; gap:4px;">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">
                            <select name="status" class="form-control form-control-sm mb-1" style="width:110px;">
                                <option value="pending" <?= $row['status']==='pending'?'selected':'' ?>>Pending</option>
                                <option value="selesai" <?= $row['status']==='selesai'?'selected':'' ?>>Selesai</option>
                            </select>
                            <input type="text" name="catatan_admin" class="form-control form-control-sm mb-1" placeholder="Catatan admin" value="<?= htmlspecialchars($row['catatan_admin']) ?>" style="width:100px;">
                            <button type="submit" name="update_status" class="btn btn-sm btn-primary ml-1">Update</button>
                            <button type="submit" name="hapus_booking" class="btn btn-sm btn-danger ml-1" onclick="return confirm('Hapus booking ini?')">Hapus</button>
                        </form>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html> 