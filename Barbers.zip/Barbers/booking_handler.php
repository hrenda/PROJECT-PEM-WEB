<?php
require 'koneksi.php';
session_start();
if (!isset($_SESSION['user_username'])) {
    header('Location: login.php');
    exit;
}
function clean($data, $conn) {
    return mysqli_real_escape_string($conn, trim($data));
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama = clean($_POST['nama'] ?? '', $conn);
    $email = clean($_POST['email'] ?? '', $conn);
    $telepon = clean($_POST['telepon'] ?? '', $conn);
    $layanan_id = (int)($_POST['layanan_id'] ?? 0);
    $komentar = clean($_POST['komentar'] ?? '', $conn);
    $tanggal = clean($_POST['tanggal'] ?? '', $conn);
    $jam = clean($_POST['jam'] ?? '', $conn);
    if ($nama && $email && $telepon && $layanan_id && $tanggal && $jam) {
        $sql = "INSERT INTO booking (nama, email, telepon, layanan_id, komentar, tanggal, jam) VALUES ('$nama', '$email', '$telepon', $layanan_id, '$komentar', '$tanggal', '$jam')";
        if (mysqli_query($conn, $sql)) {
            header('Location: contact.php?msg=Booking berhasil!');
            exit;
        } else {
            header('Location: contact.php?msg=Gagal menyimpan booking!');
            exit;
        }
    } else {
        header('Location: contact.php?msg=Semua field wajib diisi!');
        exit;
    }
} else {
    header('Location: contact.php');
    exit;
} 