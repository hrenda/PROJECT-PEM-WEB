<?php
require 'koneksi.php';
session_start();
$testimoni = mysqli_query($conn, "SELECT * FROM testimoni ORDER BY id DESC LIMIT 5");
?>
<!doctype html>
<html lang="id">
<head>
  <title>Barbers</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/bootstrap-datepicker.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/owl.theme.default.min.css">
  <link rel="stylesheet" href="fonts/flaticon/font/flaticon.css">
  <link rel="stylesheet" href="css/aos.css">
  <link rel="stylesheet" href="css/style.css">
</head>
<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">
  <div class="site-wrap" id="home-section">
    <div class="site-mobile-menu site-navbar-target">
      <div class="site-mobile-menu-header">
        <div class="site-mobile-menu-close mt-3">
          <span class="icon-close2 js-menu-toggle"></span>
        </div>
      </div>
      <div class="site-mobile-menu-body"></div>
    </div>
    <header class="site-navbar site-navbar-target" role="banner">
      <div class="container">
        <div class="row align-items-center position-relative">
          <div class="col-3 ">
            <div class="site-logo">
              <a href="index.php">Barbers</a>
            </div>
          </div>
          <div class="col-9  text-right">
            <span class="d-inline-block d-lg-none"><a href="#" class="text-white site-menu-toggle js-menu-toggle py-5 text-white"><span class="icon-menu h3 text-white"></span></a></span>
            <nav class="site-navigation text-right ml-auto d-none d-lg-block" role="navigation">
              <ul class="site-menu main-menu js-clone-nav ml-auto ">
                <li class="active"><a href="index.php" class="nav-link">Beranda</a></li>
                <li><a href="services.php" class="nav-link">Layanan</a></li>
                <li><a href="contact.php" class="nav-link">Booking</a></li>
                <?php if(isset($_SESSION['admin_username'])): ?>
                  <li><a href="bookingan.php" class="nav-link">Bookingan</a></li>
                  <li class="nav-link" style="color:#dc3545;font-weight:bold;">
                    <?= htmlspecialchars($_SESSION['admin_username']); ?>
                  </li>
                  <li><a href="logout.php" class="nav-link">Logout</a></li>
                <?php elseif(isset($_SESSION['user_username'])): ?>
                  <li><a href="riwayat.php" class="nav-link">Riwayat Booking</a></li>
                  <li class="nav-link" style="color:#dc3545;font-weight:bold;">
                    <?= htmlspecialchars($_SESSION['user_username']); ?>
                  </li>
                  <li><a href="logout.php" class="nav-link">Logout</a></li>
                <?php else: ?>

                  <li><a href="login.php" class="nav-link">Login</a></li>
                  <li><a href="register.php" class="nav-link">Daftar</a></li>
                <?php endif; ?>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <div class="ftco-blocks-cover-1">
      <div class="site-section-cover overlay" data-stellar-background-ratio="0.5" style="background-image: url('images/big_image_1.jpg')">
        <div class="container">
          <div class="row align-items-center justify-content-center text-center">
            <div class="col-md-7">
              <h1 class="mb-3">Selamat Datang di Barbers</h1>
              <p class="lead">Barbers adalah barbershop modern di Batam yang menawarkan layanan potong rambut, perawatan, dan styling terbaik untuk pria dan anak-anak. Booking online, harga transparan, pelayanan ramah!</p>
              <p><a href="contact.php" class="btn btn-primary">Booking Sekarang</a></p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="site-section">
      <div class="container">
        <div class="row">
          <div class="col-lg-6 mb-5 mb-lg-0">
              <img src="images/img_1.jpg" alt="Image" class="img-fluid">
              <div class="year"></div>
          </div>
          <div class="col-lg-5 ml-auto pl-lg-5 text-center">
            <h3 class="scissors text-center">Tentang Barbers</h3>
            <p class="mb-5 lead">Kami berdedikasi memberikan layanan potong rambut, styling, dan perawatan terbaik untuk pria dan anak-anak. Dengan barberman berpengalaman dan suasana nyaman, Barbers adalah pilihan tepat untuk penampilan Anda.</p>
            <p><a href="services.php" class="btn btn-primary">Lihat Layanan</a></p>
          </div>
        </div>
      </div>
    </div>
    <!-- Section Testimoni -->
    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-8 text-center">
            <h2 class="scissors text-center">Testimoni Pelanggan</h2>
            <p class="lead">Apa kata pelanggan tentang Barbers?</p>
          </div>
        </div>
        <div class="row">
          <?php if(mysqli_num_rows($testimoni) > 0): ?>
            <?php while($row = mysqli_fetch_assoc($testimoni)): ?>
            <div class="col-md-4 mb-4">
              <div class="p-4 bg-white rounded shadow-sm h-100 border border-danger">
                <div class="mb-2"><span class="icon-quote-left text-danger"></span></div>
                <p class="font-italic">"<?= htmlspecialchars($row['pesan']) ?>"</p>
                <p class="text-right font-weight-bold text-danger">- <?= htmlspecialchars($row['nama']) ?></p>
              </div>
            </div>
            <?php endwhile; ?>
          <?php else: ?>
            <div class="col-12 text-center text-muted">Belum ada testimoni. Jadilah yang pertama memberikan testimoni!</div>
            <!-- Contoh dummy -->
            <div class="col-md-4 mb-4">
              <div class="p-4 bg-white rounded shadow-sm h-100 border border-danger">
                <div class="mb-2"><span class="icon-quote-left text-danger"></span></div>
                <p class="font-italic">"Pelayanan ramah, hasil potongan rapi!"</p>
                <p class="text-right font-weight-bold text-danger">- Budi</p>
              </div>
            </div>
            <div class="col-md-4 mb-4">
              <div class="p-4 bg-white rounded shadow-sm h-100 border border-danger">
                <div class="mb-2"><span class="icon-quote-left text-danger"></span></div>
                <p class="font-italic">"Tempatnya nyaman, harga terjangkau."</p>
                <p class="text-right font-weight-bold text-danger">- Andi</p>
              </div>
            </div>
            <div class="col-md-4 mb-4">
              <div class="p-4 bg-white rounded shadow-sm h-100 border border-danger">
                <div class="mb-2"><span class="icon-quote-left text-danger"></span></div>
                <p class="font-italic">"Booking online gampang, hasil memuaskan!"</p>
                <p class="text-right font-weight-bold text-danger">- Sari</p>
              </div>
            </div>
          <?php endif; ?>
        </div>
      </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/jquery-migrate-3.0.0.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.sticky.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.animateNumber.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/jquery.stellar.min.js"></script>
    <script src="js/jquery.easing.1.3.js"></script>
    <script src="js/bootstrap-datepicker.min.js"></script>
    <script src="js/aos.js"></script>
    <script src="js/main.js"></script>
  </div>
</body>
</html> 