<?php
require 'koneksi.php';
session_start();
$msg = '';
// Tambah layanan (admin)
if (isset($_SESSION['admin_username']) && isset($_POST['tambah_layanan'])) {
    $nama = mysqli_real_escape_string($conn, $_POST['nama_layanan']);
    $deskripsi = mysqli_real_escape_string($conn, $_POST['deskripsi']);
    $harga = (int)$_POST['harga'];
    if ($nama && $harga) {
        mysqli_query($conn, "INSERT INTO layanan (nama_layanan, deskripsi, harga) VALUES ('$nama', '$deskripsi', $harga)");
        $msg = 'Layanan berhasil ditambah!';
    }
}
// Hapus layanan (admin)
if (isset($_SESSION['admin_username']) && isset($_GET['hapus'])) {
    $id = (int)$_GET['hapus'];
    mysqli_query($conn, "DELETE FROM layanan WHERE id=$id");
    $msg = 'Layanan berhasil dihapus!';
}
// Ambil semua layanan
$layanan = mysqli_query($conn, "SELECT * FROM layanan ORDER BY id ASC");
?>
<!doctype html>
<html lang="id">
<head>
  <title>Layanan - Barbers</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link href="https://fonts.googleapis.com/css?family=DM+Sans:300,400,700&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="fonts/icomoon/style.css">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <link rel="stylesheet" href="css/style.css">
  <style>
    .site-navbar .site-menu a { color: #dc3545 !important; font-weight: bold; }
    .site-navbar .site-menu .active > a { color: #dc3545 !important; }
  </style>
</head>
<body>
  <div class="site-wrap" id="home-section">
    <header class="site-navbar site-navbar-target" role="banner">
      <div class="container">
        <div class="row align-items-center position-relative">
          <div class="col-3 ">
            <div class="site-logo">
              <a href="index.php">Barbers</a>
            </div>
          </div>
          <div class="col-9  text-right">
            <nav class="site-navigation text-right ml-auto d-none d-lg-block" role="navigation">
              <ul class="site-menu main-menu js-clone-nav ml-auto ">
                <li><a href="index.php" class="nav-link">Beranda</a></li>
                <li class="active"><a href="services.php" class="nav-link">Layanan</a></li>
                <li><a href="contact.php" class="nav-link">Booking</a></li>
                <?php if(isset($_SESSION['admin_username'])): ?>
                  <li><a href="bookingan.php" class="nav-link">Bookingan</a></li>
                  <li class="nav-link" style="color:#dc3545;font-weight:bold;">
                    <?= htmlspecialchars($_SESSION['admin_username']); ?>
                  </li>
                  <li><a href="logout.php" class="nav-link">Logout</a></li>
                <?php else: ?>
                  <li><a href="login.php" class="nav-link">Login</a></li>
                  <li><a href="register.php" class="nav-link">Daftar</a></li>
                <?php endif; ?>
              </ul>
            </nav>
          </div>
        </div>
      </div>
    </header>
    <div class="site-section bg-light">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-8 text-center">
            <h2 class="scissors text-center">Layanan & Harga Barbers</h2>
            <p class="lead">Daftar layanan grooming dan perawatan terbaik untuk pria dan anak-anak. Semua harga transparan dan bisa dipesan online!</p>
          </div>
        </div>
        <?php if($msg): ?><div class="alert alert-info"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <div class="row">
          <div class="col-12">
            <table class="table table-bordered table-striped">
              <thead class="thead-dark">
                <tr>
                  <th>No</th>
                  <th>Layanan</th>
                  <th>Deskripsi</th>
                  <th>Harga</th>
                  <?php if(isset($_SESSION['admin_username'])): ?><th>Aksi</th><?php endif; ?>
                </tr>
              </thead>
              <tbody>
                <?php $no=1; while($row = mysqli_fetch_assoc($layanan)): ?>
                <tr>
                  <td><?= $no++ ?></td>
                  <td><?= htmlspecialchars($row['nama_layanan']) ?></td>
                  <td><?= htmlspecialchars($row['deskripsi']) ?></td>
                  <td>Rp <?= number_format($row['harga'],0,',','.') ?></td>
                  <?php if(isset($_SESSION['admin_username'])): ?>
                  <td><a href="?hapus=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus layanan ini?')">Hapus</a></td>
                  <?php endif; ?>
                </tr>
                <?php endwhile; ?>
              </tbody>
            </table>
          </div>
        </div>
        <?php if(isset($_SESSION['admin_username'])): ?>
        <div class="row mt-4">
          <div class="col-md-8 offset-md-2">
            <h4>Tambah Layanan Baru</h4>
            <form method="POST">
              <div class="form-group">
                <label>Nama Layanan</label>
                <input type="text" name="nama_layanan" class="form-control" required>
              </div>
              <div class="form-group">
                <label>Deskripsi</label>
                <textarea name="deskripsi" class="form-control"></textarea>
              </div>
              <div class="form-group">
                <label>Harga (Rp)</label>
                <input type="number" name="harga" class="form-control" required>
              </div>
              <button type="submit" name="tambah_layanan" class="btn btn-primary">Tambah Layanan</button>
            </form>
          </div>
        </div>
        <?php endif; ?>
        <div class="row justify-content-center mt-4">
          <div class="col-md-6 text-center">
            <a href="contact.php" class="btn btn-primary">Booking Sekarang</a>
          </div>
        </div>
        <?php if(mysqli_num_rows($layanan) == 0): ?>
          <?php
            // Tambah layanan dummy jika kosong
            $dummy = [
              ['nama_layanan'=>'Haircut','deskripsi'=>'Potong rambut pria & anak','harga'=>30000],
              ['nama_layanan'=>'Cuci Rambut','deskripsi'=>'Cuci rambut dengan shampoo khusus','harga'=>20000],
              ['nama_layanan'=>'Hair Spa','deskripsi'=>'Perawatan rambut & kulit kepala','harga'=>40000],
            ];
            foreach($dummy as $d) {
              mysqli_query($conn, "INSERT INTO layanan (nama_layanan, deskripsi, harga) VALUES ('{$d['nama_layanan']}', '{$d['deskripsi']}', {$d['harga']})");
            }
            $layanan = mysqli_query($conn, "SELECT * FROM layanan ORDER BY id ASC");
          ?>
        <?php endif; ?>
        <!-- Card layanan -->
        <div class="row mt-5">
          <?php mysqli_data_seek($layanan, 0); while($row = mysqli_fetch_assoc($layanan)): ?>
          <div class="col-md-4 mb-4">
            <div class="card border-danger h-100">
              <div class="card-body">
                <h5 class="card-title text-danger font-weight-bold"><?= htmlspecialchars($row['nama_layanan']) ?></h5>
                <p class="card-text"><?= htmlspecialchars($row['deskripsi']) ?></p>
                <p class="card-text font-weight-bold">Rp <?= number_format($row['harga'],0,',','.') ?></p>
              </div>
            </div>
          </div>
          <?php endwhile; ?>
        </div>
      </div>
    </div>
    <script src="js/jquery-3.3.1.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
  </div>
</body>
</html> 