<?php
require 'koneksi.php';
session_start();
$msg = $_GET['msg'] ?? '';
$layanan = mysqli_query($conn, "SELECT * FROM layanan ORDER BY id ASC");
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Booking Barbers</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h2>Form Booking Barbers</h2>
        <?php if($msg): ?><div class="alert alert-info"><?= htmlspecialchars($msg) ?></div><?php endif; ?>
        <?php if(!isset($_SESSION['user_username'])): ?>
            <div class="alert alert-warning">Anda harus login/daftar dulu untuk melakukan booking.</div>
            <a href="register.php" class="btn btn-danger">Daftar</a>
            <a href="login.php" class="btn btn-primary ml-2">Login</a>
        <?php else: ?>
        <form action="booking_handler.php" method="POST">
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="nama" class="form-control" value="<?= htmlspecialchars($_SESSION['user_username']) ?>" readonly>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Nomor Telepon</label>
                <input type="text" name="telepon" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Layanan</label>
                <select name="layanan_id" class="form-control" required>
                    <option value="">-- Pilih Layanan --</option>
                    <?php while($row = mysqli_fetch_assoc($layanan)): ?>
                    <option value="<?= $row['id'] ?>"><?= htmlspecialchars($row['nama_layanan']) ?> (Rp <?= number_format($row['harga'],0,',','.') ?>)</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Komentar</label>
                <textarea name="komentar" class="form-control"></textarea>
            </div>
            <div class="form-group">
                <label>Tanggal Booking</label>
                <input type="date" name="tanggal" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Jam Booking</label>
                <input type="time" name="jam" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Kirim Booking</button>
        </form>
        <?php endif; ?>
        <div class="text-center mt-4">
            <a href="index.php" class="btn btn-secondary">&larr; Kembali ke Beranda</a>
        </div>
    </div>
</body>
</html> 